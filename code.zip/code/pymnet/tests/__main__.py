import sys
from . import test_all

sys.exit(not test_all())
